# file: src/strategy/pivot_corr_engine.py
# English-only comments

from __future__ import annotations
from datetime import datetime, timedelta
from decimal import Decimal
import threading
from typing import Any, Dict, List, Optional, Tuple

import psycopg  # psycopg3

# Access CandleBuffer to read close prices
from buffers import buffer_initializer as buffers
from buffers.candle_buffer import Keys

# Shared registry provider for pivots
from pivots.pivot_registry_provider import get_pivot_registry

# Cross-trigger signal dedup (across events)
from signals.signal_registry import get_signal_registry


# --------------------------------------------------------------------
# Core State Classes
# --------------------------------------------------------------------

class SignalMemory:
    """
    Keeps a memory of processed signals WITHIN ONE run_decision_event call.

    This is only a local memory for the current event.
    For cross-event deduplication, we use signal_registry.
    """
    def __init__(self) -> None:
        self._seen: set[str] = set()
        self._lock = threading.Lock()

    def remember(self, uid: str) -> bool:
        """
        Remember a unique signal key.
        Return True if it is NEW, False if seen before during this run.
        """
        with self._lock:
            if uid in self._seen:
                return False
            self._seen.add(uid)
            return True


# --------------------------------------------------------------------
# Public API
# --------------------------------------------------------------------

def run_decision_event(
    *,
    exchange: str,
    symbols: List[str],
    timeframe: str,
    event_time: datetime,                 # just-closed candle time (trigger)
    signal_memory: SignalMemory,
    groups: Optional[Dict[str, List[str]]] = None,  # SAME/OPP groups
    conn: Optional[psycopg.Connection] = None,      # DB connection
    max_lookback: int = 50,
    window: int = 3                                   # +/- minutes for matching
) -> None:
    """
    Main correlation engine for pivot-based signals.

    Strategy (CURRENT):

      • For each ref_symbol in `symbols` and ref_type in {HIGH, LOW}:
        – Iterate over ref pivots newest→oldest (up to max_lookback).
        – For each ref pivot:
            • Find SAME-group pivots of SAME type within ±window minutes.
            • Find OPP-group pivots of OPPOSITE type within ±window minutes.
            • For each of the 5 symbols, decide if its pivot is "hit":
                ref: ref_hit
                peers: (found AND hit)

      • total_hits = number of symbols whose pivot is hit (ref + peers).

      • Rule:
          If total_hits >= 3:
            → Generate signals on symbols that:
                - are NOT "DXY/DXY"
                - have pivot found = True
                - have pivot hit = False
            (Ref can also be a target when its pivot is not hit.)

      • SAME / OPP only affect which pivot type we look for; direction is
        currently HIGH→buy, LOW→sell (you can refine later).

      • Each signal:
          - position_price: from CandleBuffer around event_time
                            (with robust fallback).
          - If price lookup fails, we may fallback to pivot_level and log a
            warning instead of silently skipping.
          - target_pips and target_price computed from pivot-level vs price.
          - Dedup via:
              * local in-run set (emitted_local),
              * global signal_registry.

      • Additionally:
          - Always write rows into pivot_loop_log.
          - Write generated signals into signals table.
    """
    reg = get_pivot_registry()
    sig_registry = get_signal_registry()

    # Resolve group A / B for SAME/OPP
    same_group, opposite_group = _resolve_two_groups(groups, symbols)

    # Pre-cache peer pivots per (symbol, "HIGH"/"LOW")
    cache: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}

    def pivots_for(sym: str, ptype: str) -> List[Dict[str, Any]]:
        """Fetch pivots from registry (with max_lookback) and cache them."""
        key = (sym, ptype)
        if key not in cache:
            cache[key] = _collect_pivots_from_registry(
                exchange, sym, timeframe, ptype, max_lookback=max_lookback
            )
        return cache[key]

    # Batches for DB writes
    batch_rows_looplog: List[tuple] = []
    batch_rows_signals: List[tuple] = []

    # LOCAL (per-event) dedup:
    # key: (symbol, side, found_at_minute)
    emitted_local: set[Tuple[str, str, datetime]] = set()

    # ----------------------------------------------------------------
    # Main loop over each ref symbol and HIGH/LOW type
    # ----------------------------------------------------------------
    for ref_symbol in symbols:
        # Determine which are SAME vs OPP relative to ref_symbol
        if ref_symbol in same_group:
            peers_same = [s for s in same_group if s != ref_symbol]
            peers_opp = list(opposite_group)
        elif ref_symbol in opposite_group:
            peers_same = [s for s in opposite_group if s != ref_symbol]
            peers_opp = list(same_group)
        else:
            # Fallback: if symbol not in any group, treat all others as SAME
            peers_same = [s for s in symbols if s != ref_symbol]
            peers_opp = []

        for ref_type in ("HIGH", "LOW"):
            ref_pivots = pivots_for(ref_symbol, ref_type)

            # Newest -> oldest within max_lookback
            for _, rp in enumerate(ref_pivots, start=1):
                pivot_time = rp.get("close_time") or rp.get("time")
                ref_hit = bool(rp.get("hit"))
                ref_level = rp.get("level")

                # SAME-type peers
                rows_same, _ = _compare_ref_with_peers(
                    ref_symbol=ref_symbol,
                    ref_type=ref_type,
                    ref_time=pivot_time,
                    peers=peers_same,
                    peer_type=ref_type,
                    pivots_fetcher=pivots_for,
                    window=window,
                )

                # OPP-type peers
                opposite_type = "LOW" if ref_type == "HIGH" else "HIGH"
                rows_opp, _ = _compare_ref_with_peers(
                    ref_symbol=ref_symbol,
                    ref_type=ref_type,
                    ref_time=pivot_time,
                    peers=peers_opp,
                    peer_type=opposite_type,
                    pivots_fetcher=pivots_for,
                    window=window,
                )

                # ----------------------------------------------------
                # 1) Write pivot_loop_log rows for SAME + OPP peers
                # ----------------------------------------------------
                for rec in rows_same:
                    found_at = rec["time"] if rec["found"] and isinstance(rec["time"], datetime) else None
                    delta_minute = _signed_minutes(found_at, pivot_time) if found_at else None
                    batch_rows_looplog.append((
                        event_time,
                        ref_symbol,
                        ref_type,
                        "SAME",
                        pivot_time,
                        ref_hit,
                        rec["symbol"],
                        bool(rec["found"]),
                        bool(rec["hit"]),
                        delta_minute,
                        found_at,
                    ))

                for rec in rows_opp:
                    found_at = rec["time"] if rec["found"] and isinstance(rec["time"], datetime) else None
                    delta_minute = _signed_minutes(found_at, pivot_time) if found_at else None
                    batch_rows_looplog.append((
                        event_time,
                        ref_symbol,
                        ref_type,
                        "OPP",
                        pivot_time,
                        ref_hit,
                        rec["symbol"],
                        bool(rec["found"]),
                        bool(rec["hit"]),
                        delta_minute,
                        found_at,
                    ))

                # ----------------------------------------------------
                # 2) Decision logic: count hits
                # ----------------------------------------------------
                comp_by_symbol: Dict[str, Dict[str, Any]] = {
                    c["symbol"]: c for c in (rows_same + rows_opp)
                }

                # ref symbol uses its own hit flag
                hit_map: Dict[str, bool] = {ref_symbol: bool(ref_hit)}
                # peers use found & hit
                for c in comp_by_symbol.values():
                    hit_map[c["symbol"]] = bool(c["found"] and c["hit"])

                total_hits = sum(1 for v in hit_map.values() if v)
                confirm_syms_str = ", ".join([s for s, v in hit_map.items() if v])

                # DEBUG: you can comment this out later
                # print(f"[DEBUG] round ref={ref_symbol} {ref_type} @ {pivot_time} | total_hits={total_hits} | hits=[{confirm_syms_str}]")

                # Rule: only check total_hits >= 3 (no upper bound)
                if total_hits < 3:
                    # Not enough confirmation; we still keep pivot_loop_log rows,
                    # but skip signal generation.
                    continue

                # If we don't have a DB connection, skip signals entirely.
                if conn is None:
                    print("[SKIP] conn is None, cannot write signals.")
                    continue

                # ----------------------------------------------------
                # 3) For each symbol, decide if it becomes a signal target
                # ----------------------------------------------------
                for tgt in symbols:
                    # Never generate a signal ON DXY itself
                    if tgt == "DXY/DXY":
                        continue

                    # Already-hit symbols are confirmers, not targets
                    if hit_map.get(tgt, False):
                        continue

                    expected_type: Optional[str] = None
                    pivot_level: Optional[Decimal] = None
                    found_at: Optional[datetime] = None

                    if tgt == ref_symbol:
                        # Target is the ref itself; ref pivot is always "found"
                        expected_type = ref_type
                        if ref_level is not None:
                            pivot_level = Decimal(str(ref_level))
                        found_at = pivot_time
                    else:
                        # Non-ref target: must have a matched pivot
                        c = comp_by_symbol.get(tgt)
                        if not c or not c.get("found"):
                            print(f"[SKIP] target={tgt} | reason=no matched pivot found")
                            continue
                        expected_type = c["type"]
                        found_at = c.get("time")
                        lvl = c.get("level")
                        if lvl is not None:
                            pivot_level = Decimal(str(lvl))
                        else:
                            pivot_level = None  # we handle this later

                    if expected_type is None or found_at is None:
                        print(f"[SKIP] target={tgt} | reason=missing expected_type or found_at")
                        continue

                    # ------------------------------------------------
                    # 4) Get position_price (with robust + fallback)
                    # ------------------------------------------------
                    position_price = _get_close_price_robust(
                        exchange, tgt, timeframe, event_time, fallback_time=found_at
                    )

                    if position_price is None and pivot_level is not None:
                        # Use pivot_level as last-resort entry price
                        position_price = pivot_level
                        print(
                            "[WARN] price None, using pivot_level as entry | "
                            f"target={tgt}, event_time={event_time}, pivot_time={found_at}"
                        )
                    elif position_price is None and pivot_level is None:
                        print(
                            f"[SKIP] target={tgt} | reason=no price and no pivot_level "
                            f"(event_time={event_time}, pivot_time={found_at})"
                        )
                        continue

                    # If pivot_level is still None but we have a price,
                    # set pivot_level = price (pips = 0, but signal exists).
                    if pivot_level is None:
                        pivot_level = position_price
                        print(
                            f"[WARN] target={tgt} | pivot_level=None, "
                            "using position_price as pivot_level (pips=0)."
                        )

                    # Side: CURRENTLY HIGH => buy, LOW => sell
                    side = "buy" if expected_type == "HIGH" else "sell"

                    # Normalize pivot time to minute for dedup keys
                    found_at_minute = found_at.replace(second=0, microsecond=0)

                    local_key = (tgt.upper(), side, found_at_minute)

                    # DEBUG candidate
                    print(
                        "[DEBUG] candidate_signal "
                        f"target={tgt} side={side} ref={ref_symbol} {ref_type} "
                        f"pivot_time={pivot_time} found_at={found_at_minute} "
                        f"total_hits={total_hits}"
                    )

                    # 1) In-run dedup (this event only)
                    if local_key in emitted_local:
                        print(
                            f"[SKIP] target={tgt} side={side} | reason=local duplicate "
                            f"(found_at={found_at_minute})"
                        )
                        continue
                    emitted_local.add(local_key)

                    # 2) Cross-trigger dedup (across events)
                    if not sig_registry.remember(tgt, side, found_at_minute):
                        print(
                            f"[SKIP] target={tgt} side={side} | reason=global duplicate "
                            f"(found_at={found_at_minute})"
                        )
                        continue

                    # 3) Compute targets
                    target_pips = _pips(tgt, pivot_level, position_price)
                    target_price = _price_from_pips(tgt, position_price, target_pips)

                    # Also remember in local SignalMemory (for debugging parity)
                    signal_memory.remember(
                        f"{tgt}|{side}|{found_at_minute.isoformat()}"
                    )

                    # 4) Print human-readable signal info
                    print(
                        "[SIGNAL] "
                        f"event_time={event_time} | target={tgt} | side={side} | "
                        f"position_price={position_price} | target_price={target_price} | "
                        f"target_pips={target_pips} | "
                        f"confirm_symbols=[{confirm_syms_str}] | "
                        f"ref={ref_symbol} {ref_type} @ {pivot_time} | "
                        f"found_at={found_at_minute}"
                    )

                    # 5) Queue row for signals table INSERT
                    batch_rows_signals.append((
                        event_time,             # event_time (trigger)
                        tgt,                    # signal_symbol
                        confirm_syms_str,       # confirm_symbols
                        side,                   # position_type
                        position_price,         # position_price
                        target_pips,            # target_pips
                        target_price,           # target_price
                        ref_symbol,             # ref_symbol (context)
                        ref_type,               # ref_type (context)
                        pivot_time,             # pivot_time (ref anchor)
                        found_at_minute,        # found_at (target pivot time)
                    ))

    # ----------------------------------------------------------------
    # 6) Batch DB writes
    # ----------------------------------------------------------------
    if conn:
        if batch_rows_looplog:
            _insert_pivot_loop_log(conn, batch_rows_looplog)
        if batch_rows_signals:
            print(batch_rows_signals)  # keep for debugging; remove later if noisy
            _insert_signals(conn, batch_rows_signals)


# --------------------------------------------------------------------
# Peer comparison helpers
# --------------------------------------------------------------------

def _compare_ref_with_peers(
    *,
    ref_symbol: str,
    ref_type: str,
    ref_time: datetime,     # pivot_time anchor
    peers: List[str],
    peer_type: str,
    pivots_fetcher,
    window: int,
) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
    """
    For a given ref pivot (ref_symbol, ref_type, ref_time),
    scan each peer symbol and attempt to find a pivot of peer_type
    whose time is within +/- `window` minutes of ref_time.

    Returns
    -------
    comparisons : List[Dict[str, Any]]
        One dict per peer, with:
          symbol, type, found, time, hit, delta_min, level, uid
    stats : Dict[str, int]
        Simple stats, currently: {"hit": <count_of_hit_peers>}
    """
    comparisons: List[Dict[str, Any]] = []
    hit_counter = 0

    for peer in peers:
        piv_list = pivots_fetcher(peer, peer_type)
        matched = _find_pivot_in_window(piv_list, ref_time, window_minutes=window)

        if matched is None:
            # No pivot for this peer in the allowed window
            comparisons.append({
                "symbol": peer,
                "type": peer_type,
                "found": False,
                "time": None,
                "hit": False,
                "delta_min": None,
                "level": None,
                "uid": None,
            })
            continue

        mp = matched
        m_time = mp.get("close_time") or mp.get("time")
        m_hit = bool(mp.get("hit"))
        m_level = mp.get("level")
        delta_m_abs = abs(_signed_minutes(m_time, ref_time))

        if m_hit:
            hit_counter += 1

        comparisons.append({
            "symbol": peer,
            "type": peer_type,
            "found": True,
            "time": m_time,
            "hit": m_hit,
            "delta_min": delta_m_abs,
            "level": m_level,
            "uid": mp.get("uid"),
        })

    return comparisons, {"hit": hit_counter}


def _find_pivot_in_window(
    pivots: List[Dict[str, Any]],
    ref_time: datetime,
    window_minutes: int,
) -> Optional[Dict[str, Any]]:
    """
    Select the best pivot from a list that falls within +/- window_minutes
    of ref_time. "Best" = smallest absolute time difference.

    Assumes pivots are ordered newest-first.
    """
    best: Optional[Tuple[int, Dict[str, Any]]] = None  # (abs_delta_minutes, pivot_dict)

    for p in pivots:
        t = p.get("close_time") or p.get("time")
        if not isinstance(t, datetime):
            continue

        delta = abs(_signed_minutes(t, ref_time))
        if delta <= window_minutes:
            if best is None or delta < best[0]:
                best = (delta, p)
                if delta == 0:
                    # Exact match is the best we can get
                    break

    return best[1] if best else None


# --------------------------------------------------------------------
# Registry access & DB IO helpers
# --------------------------------------------------------------------

def _insert_pivot_loop_log(conn: psycopg.Connection, rows: List[tuple]) -> None:
    """
    Insert many rows into pivot_loop_log in one batch.

    Columns:
      (event_time, ref_symbol, ref_type, peer_type, pivot_time, ref_is_hit,
       symbol_compare, is_found, is_hit, delta_minute, found_at)
    """
    sql = """
        INSERT INTO pivot_loop_log (
            event_time,
            ref_symbol,
            ref_type,
            peer_type,
            pivot_time,
            ref_is_hit,
            symbol_compare,
            is_found,
            is_hit,
            delta_minute,
            found_at
        ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """
    with conn.cursor() as cur:
        cur.executemany(sql, rows)
    conn.commit()


def _insert_signals(conn: psycopg.Connection, rows: List[tuple]) -> None:
    """
    Insert generated signals in one batch.

    Columns:
      (event_time, signal_symbol, confirm_symbols, position_type,
       position_price, target_pips, target_price,
       ref_symbol, ref_type, pivot_time, found_at)
    """
    sql = """
        INSERT INTO signals (
            event_time,
            signal_symbol,
            confirm_symbols,
            position_type,
            position_price,
            target_pips,
            target_price,
            ref_symbol,
            ref_type,
            pivot_time,
            found_at
        ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """
    with conn.cursor() as cur:
        cur.executemany(sql, rows)
    conn.commit()


def _collect_pivots_from_registry(
    exchange: str,
    symbol: str,
    timeframe: str,
    pivot_type: str,
    max_lookback: int,
) -> List[Dict[str, Any]]:
    """
    Read pivots for (exchange, symbol, timeframe) from PivotBufferRegistry,
    map them to simple dicts, and return newest-first.

    Expected pivot object attributes:
      - time / close_time
      - level
      - hit / is_hit
      - uid
    """
    reg = get_pivot_registry()
    pb = reg.get(exchange, symbol, timeframe)
    if pb is None:
        return []

    out: List[Dict[str, Any]] = []

    if pivot_type.upper() == "HIGH":
        it = pb.iter_peaks_newest_first()
    else:
        it = pb.iter_lows_newest_first()

    for p in it:
        close_t = getattr(p, "close_time", None)
        time_t = getattr(p, "time", None)
        hit_v = getattr(p, "hit", getattr(p, "is_hit", False))

        out.append({
            "time": time_t,
            "close_time": close_t or time_t,
            "hit": bool(hit_v),
            "level": getattr(p, "level", None),
            "uid": getattr(p, "uid", None),
        })

        if len(out) >= max_lookback:
            break

    return out


# --------------------------------------------------------------------
# Candle & Price/Pip helpers
# --------------------------------------------------------------------

def _get_close_price_from_buffer_exact(
    exchange: str,
    symbol: str,
    timeframe: str,
    t: datetime,
) -> Optional[Decimal]:
    """
    Try to read the EXACT close price at time=t from CandleBuffer.

    This relies on CandleBuffer implementing one of:
      • get_by_time(t)
      • at(t)
      • get(t)

    Returns Decimal if successful, otherwise None.
    """
    try:
        cb = getattr(buffers, "CANDLE_BUFFER", None)
        if cb is None:
            return None

        key = Keys(exchange, symbol, timeframe)
        buf = cb.get(key)
        if buf is None:
            return None

        c = None
        if hasattr(buf, "get_by_time"):
            c = buf.get_by_time(t)
        elif hasattr(buf, "at"):
            c = buf.at(t)  # type: ignore
        elif hasattr(buf, "get"):
            c = buf.get(t)  # type: ignore

        if c is None:
            return None

        # Try several attribute / key names for close
        for attr in ("close", "c", "Close", "C"):
            if hasattr(c, attr):
                return Decimal(str(getattr(c, attr)))
            if isinstance(c, dict) and attr in c:
                return Decimal(str(c[attr]))

        return None
    except Exception:
        # Robust: ignore all exceptions and just return None
        return None


def _get_close_price_robust(
    exchange: str,
    symbol: str,
    timeframe: str,
    event_time: datetime,
    *,
    fallback_time: Optional[datetime],
) -> Optional[Decimal]:
    """
    Robust price fetch helper:

      1) Try exact event_time.
      2) If not found, scan backward up to 3 minutes.
      3) If still not found, try exact fallback_time.

    Returns Decimal or None.
    """
    # 1) Exact at event_time
    price = _get_close_price_from_buffer_exact(exchange, symbol, timeframe, event_time)
    if price is not None:
        return price

    # 2) Scan backward 1..3 minutes
    for i in range(1, 4):
        candidate_time = event_time - timedelta(minutes=i)
        p = _get_close_price_from_buffer_exact(exchange, symbol, timeframe, candidate_time)
        if p is not None:
            return p

    # 3) Fallback: exact pivot time
    if fallback_time is not None:
        return _get_close_price_from_buffer_exact(exchange, symbol, timeframe, fallback_time)

    return None


def _pip_size(symbol: str) -> Decimal:
    """
    Return pip size (in price units) for the given symbol.

    Simplified rule:
      - If symbol contains "JPY" or "DXY" => pip = 0.01
      - Otherwise => pip = 0.0001
    """
    s = symbol.upper()
    if "JPY" in s or "DXY" in s:
        return Decimal("0.01")
    return Decimal("0.0001")


def _pips(symbol: str, pivot_level: Decimal, close_price: Decimal) -> Decimal:
    """
    (pivot_level - close_price) expressed in pips (signed).

    Positive => pivot above price,
    Negative => pivot below price.
    """
    size = _pip_size(symbol)
    return (pivot_level - close_price) / size


def _price_from_pips(symbol: str, price: Decimal, pips: Decimal) -> Decimal:
    """
    Convert pips back to a price:
        price + pips * pip_size(symbol)
    """
    size = _pip_size(symbol)
    return price + (pips * size)


# --------------------------------------------------------------------
# Small utilities
# --------------------------------------------------------------------

def _signed_minutes(t1: Optional[datetime], t2: Optional[datetime]) -> int:
    """
    Signed difference in minutes:

      > 0  if t1 is after t2
      < 0  if t1 is before t2
      = 0  if same minute
    """
    if t1 is None or t2 is None:
        return 0
    return int((t1 - t2).total_seconds() // 60)


def _resolve_two_groups(
    groups: Optional[Dict[str, List[str]]],
    symbols: List[str],
) -> Tuple[List[str], List[str]]:
    """
    Resolve two symbol groups from `groups` dict.

    Example:
      {
          "GROUP_A": ["EUR/USD", "GBP/USD", "AUD/USD"],
          "GROUP_B": ["USD/CHF", "DXY/DXY"]
      }

    We only care about the lists, not keys.

    Returns:
      same_group, opposite_group
    """
    if not groups:
        return list(symbols), []

    vals = [list(v) for v in groups.values() if v]
    if not vals:
        return list(symbols), []

    if len(vals) == 1:
        same = vals[0]
        opp = [s for s in symbols if s not in same]
        return same, opp

    # If there are 2+ lists, just use the first two.
    return vals[0], vals[1]
